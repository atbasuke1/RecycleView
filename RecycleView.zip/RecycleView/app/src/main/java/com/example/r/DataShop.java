package com.example.r;

public class DataShop {
    private int Hinhanh;
    private String Ten;

    public DataShop(int hinhanh, String ten) {
        Hinhanh = hinhanh;
        Ten = ten;
    }

    public void setHinhanh(int hinhanh) {
        Hinhanh = hinhanh;
    }

    public void setTen(String ten) {
        Ten = ten;
    }

    public int getHinhanh() {
        return Hinhanh;
    }

    public String getTen() {
        return Ten;
    }
}
